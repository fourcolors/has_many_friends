ActiveRecord::Base.send( :include, HasManyFriends::UserExtensions )
